

```python
import tensorflow as tf
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn import linear_model
from sklearn.metrics import mean_squared_error,r2_score
from sklearn.model_selection import train_test_split
powerplant = pd.read_csv('C:/Users/Administrator/Desktop/PYTHON CRASH COURSE/pwrplant.csv')
powerplant.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>AT</th>
      <th>V</th>
      <th>AP</th>
      <th>RH</th>
      <th>PE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>14.96</td>
      <td>41.76</td>
      <td>1024.07</td>
      <td>73.17</td>
      <td>463.26</td>
    </tr>
    <tr>
      <th>1</th>
      <td>25.18</td>
      <td>62.96</td>
      <td>1020.04</td>
      <td>59.08</td>
      <td>444.37</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5.11</td>
      <td>39.40</td>
      <td>1012.16</td>
      <td>92.14</td>
      <td>488.56</td>
    </tr>
    <tr>
      <th>3</th>
      <td>20.86</td>
      <td>57.32</td>
      <td>1010.24</td>
      <td>76.64</td>
      <td>446.48</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10.82</td>
      <td>37.50</td>
      <td>1009.23</td>
      <td>96.62</td>
      <td>473.90</td>
    </tr>
  </tbody>
</table>
</div>




```python
powerplant.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>AT</th>
      <th>V</th>
      <th>AP</th>
      <th>RH</th>
      <th>PE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>9568.000000</td>
      <td>9568.000000</td>
      <td>9568.000000</td>
      <td>9568.000000</td>
      <td>9568.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>19.651231</td>
      <td>54.305804</td>
      <td>1013.259078</td>
      <td>73.308978</td>
      <td>454.365009</td>
    </tr>
    <tr>
      <th>std</th>
      <td>7.452473</td>
      <td>12.707893</td>
      <td>5.938784</td>
      <td>14.600269</td>
      <td>17.066995</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.810000</td>
      <td>25.360000</td>
      <td>992.890000</td>
      <td>25.560000</td>
      <td>420.260000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>13.510000</td>
      <td>41.740000</td>
      <td>1009.100000</td>
      <td>63.327500</td>
      <td>439.750000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>20.345000</td>
      <td>52.080000</td>
      <td>1012.940000</td>
      <td>74.975000</td>
      <td>451.550000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>25.720000</td>
      <td>66.540000</td>
      <td>1017.260000</td>
      <td>84.830000</td>
      <td>468.430000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>37.110000</td>
      <td>81.560000</td>
      <td>1033.300000</td>
      <td>100.160000</td>
      <td>495.760000</td>
    </tr>
  </tbody>
</table>
</div>




```python
powerplant.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 9568 entries, 0 to 9567
    Data columns (total 5 columns):
    AT    9568 non-null float64
    V     9568 non-null float64
    AP    9568 non-null float64
    RH    9568 non-null float64
    PE    9568 non-null float64
    dtypes: float64(5)
    memory usage: 373.8 KB
    


```python
powerplant.shape
```




    (9568, 5)




```python
X= powerplant.iloc[:,0:4]
y= powerplant.iloc[:,4]
```


```python
X_train,X_test,y_train,y_test = train_test_split(X,y, test_size=0.2, random_state=42)
```


```python
print(X_train.shape)
print(X_test.shape)
print(y_train.shape)
print(y_test.shape)
```

    (7654, 4)
    (1914, 4)
    (7654,)
    (1914,)
    


```python
regression = linear_model.LinearRegression()
regression.fit(X_train,y_train)
```




    LinearRegression(copy_X=True, fit_intercept=True, n_jobs=None,
             normalize=False)




```python
y_pred = regression.predict(X_test)
print(y_pred)
```

    [455.68020791 438.73212215 434.16444    ... 482.16817365 435.41524413
     458.76150613]
    


```python
print('Coefficient for 4 features', regression.coef_)
```

    Coefficient for 4 features [-1.98589969 -0.23209358  0.06219991 -0.15811779]
    


```python
plt.style.use('seaborn')
fig, ax = plt.subplots()
ax.scatter(X_train.iloc[:,0],y_train, color='red')

ax.set_title("Linear Regression", fontsize=24,color='green')
ax.set_xlabel("AT(Ambient Temperature)", fontsize=14,color='green')
ax.set_ylabel("Energy output", fontsize=14,color='green')

   # Set size of tick labels.
ax.tick_params(axis='both', which='major', labelsize=14)


plt.show()
```


![png](output_10_0.png)



```python
print('Mean Squared Error:',mean_squared_error(y_test,y_pred))
```

    Mean Squared Error: 20.273705999687426
    


```python
print("Variance Score",r2_score(y_test,y_pred))
```

    Variance Score 0.9301046431962188
    


```python
plt.style.use('seaborn')
fig, ax = plt.subplots()
ax.scatter(X_train.iloc[:,1],y_train, color='green')

   
ax.set_title("Linear Regression", fontsize=24,color='green')
ax.set_xlabel("Ambient Temperature", fontsize=14,color='green')
ax.set_ylabel("Energy output", fontsize=14,color='green')

  
ax.tick_params(axis='both', which='major', labelsize=14)


plt.show()
```


![png](output_13_0.png)



```python
plt.style.use('seaborn')
fig, ax = plt.subplots()
ax.scatter(X_train.iloc[:,2],y_train, color='blue')

   
ax.set_title("Linear Regression", fontsize=24,color='green')
ax.set_xlabel("Ambient Pressure", fontsize=14,color='green')
ax.set_ylabel("Energy output", fontsize=14,color='green')

  
ax.tick_params(axis='both', which='major', labelsize=14)


plt.show()


```


![png](output_14_0.png)



```python

```


```python
plt.style.use('seaborn')
fig, ax = plt.subplots()
ax.scatter(X_train.iloc[:,3],y_train, color='brown')

   
ax.set_title("Linear Regression", fontsize=24,color='green')
ax.set_xlabel("Relative Humidity", fontsize=14,color='green')
ax.set_ylabel("Energy output", fontsize=14,color='green')

  
ax.tick_params(axis='both', which='major', labelsize=14)


plt.show()


```


![png](output_16_0.png)



```python

```
